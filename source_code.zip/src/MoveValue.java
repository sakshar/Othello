import javafx.util.Pair;

/**
 * Created by Asus on 12/9/2017.
 */
public class MoveValue {
    public Pair<Integer, Integer> returnMove;
    public double returnValue;

    public MoveValue(Pair<Integer, Integer> returnMove, double returnValue) {
        this.returnMove = returnMove;
        this.returnValue = returnValue;
    }

    public MoveValue(Pair<Integer, Integer> returnMove) {
        this.returnMove = returnMove;
    }

    public MoveValue(double returnValue) {
        this.returnValue = returnValue;
    }

    public MoveValue(){
        returnValue = 0.0;
    }
}
