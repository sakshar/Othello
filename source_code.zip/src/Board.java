import javafx.util.Pair;

import java.util.ArrayList;

/**
 * Created by Asus on 12/7/2017.
 */
public class Board {
    public int[][] gameBoard;
    public int whiteCount;
    public int blackCount;

    public Board(){
        gameBoard = new int[8][8];
        whiteCount = 0;
        blackCount = 0;
    }

    public void initBoard(){
        gameBoard[3][3] = -1;
        gameBoard[4][4] = -1;
        gameBoard[3][4] = 1;
        gameBoard[4][3] = 1;
        whiteCount = 2;
        blackCount = 2;
    }

    public void countBlackWhite(){
        blackCount = whiteCount = 0;
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(gameBoard[i][j] == 1)
                    blackCount++;
                else if(gameBoard[i][j] == -1)
                    whiteCount++;
            }
        }
    }

    public ArrayList<Pair<Integer,Integer>> validMoves(int player){
        ArrayList<Pair<Integer,Integer>> legalPositions = new ArrayList<>();

        int opponent = player*(-1);
        int k,l;
        boolean legal = false;
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                if(gameBoard[i][j] == 0){
                    boolean[] dir = checkNeighbor(i,j,opponent);
                    if(dir[0]){
                        k = j+2;
                        while(k < 8){
                            if(gameBoard[i][k] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[i][k] == 0) break;
                            k++;
                        }
                    }
                    if(dir[1] && !legal){
                        k = j-2;
                        while(k >= 0){
                            if(gameBoard[i][k] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[i][k] == 0) break;
                            k--;
                        }
                    }
                    if(dir[2] && !legal){
                        k = i-2;
                        while(k >= 0){
                            if(gameBoard[k][j] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][j] == 0) break;
                            k--;
                        }
                    }
                    if(dir[3] && !legal){
                        k = i+2;
                        while(k < 8){
                            if(gameBoard[k][j] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][j] == 0) break;
                            k++;
                        }
                    }
                    if(dir[4] && !legal){
                        k = i-2;
                        l = j+2;
                        while(k >= 0 && l < 8){
                            if(gameBoard[k][l] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][l] == 0) break;
                            k--;
                            l++;
                        }
                    }
                    if(dir[5] && !legal){
                        k = i+2;
                        l = j-2;
                        while(k < 8 && l >= 0){
                            if(gameBoard[k][l] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][l] == 0) break;
                            k++;
                            l--;
                        }
                    }
                    if(dir[6] && !legal){
                        k = i+2;
                        l = j+2;
                        while(k < 8 && l < 8){
                            if(gameBoard[k][l] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][l] == 0) break;
                            k++;
                            l++;
                        }
                    }
                    if(dir[7] && !legal){
                        k = i-2;
                        l = j-2;
                        while(k >= 0 && l >= 0){
                            if(gameBoard[k][l] == player) {
                                legal = true;
                                break;
                            }
                            if(gameBoard[k][l] == 0) break;
                            k--;
                            l--;
                        }
                    }
                    if(legal){
                        legalPositions.add(new Pair<>(i,j));
                        legal = false;
                    }
                }
            }
        }

        return legalPositions;
    }

    public void printLegalMoves(ArrayList<Pair<Integer,Integer>> legalMoves){
        System.out.println("Legal Moves:");
        for(Pair<Integer,Integer> pair: legalMoves){
            System.out.print("("+String.valueOf(pair.getKey()+1)+", "+String.valueOf(pair.getValue()+1)+") ");
        }
        System.out.println("");
    }

    public boolean[] checkNeighbor(int i, int j, int opponent){
        boolean[] dir = new boolean[8];
        if(j+1 < 8 && gameBoard[i][j+1] == opponent) dir[0] = true;
        if(j-1 >= 0 && gameBoard[i][j-1] == opponent) dir[1] = true;
        if(i-1 >= 0 && gameBoard[i-1][j] == opponent) dir[2] = true;
        if(i+1 < 8 && gameBoard[i+1][j] == opponent) dir[3] = true;
        if(i-1 >= 0 && j+1 < 8 && gameBoard[i-1][j+1] == opponent) dir[4] = true;
        if(i+1 < 8 && j-1 >= 0 && gameBoard[i+1][j-1] == opponent) dir[5] = true;
        if(i+1 < 8 && j+1 < 8 && gameBoard[i+1][j+1] == opponent) dir[6] = true;
        if(i-1 >= 0 && j-1 >= 0 && gameBoard[i-1][j-1] == opponent) dir[7] = true;
        return dir;
    }

    public int[] checkDirectionForExecute(int i, int j, int opponent){
        int[] dir = new int[8];
        int k,l;
        k = j+1;
        if(k < 8 && gameBoard[i][k] == opponent) {
            int flag = 0;
            int count = 0;
            while(k < 8) {
                if(gameBoard[i][k] == opponent) count++;
                if(gameBoard[i][k] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[i][k] == 0) break;
                k++;
            }
            if(flag == 1) dir[0] = count;
        }
        k = j-1;
        if(k >= 0 && gameBoard[i][k] == opponent) {
            int flag = 0;
            int count = 0;
            while(k >= 0) {
                if(gameBoard[i][k] == opponent) count++;
                if(gameBoard[i][k] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[i][k] == 0) break;
                k--;
            }
            if(flag == 1) dir[1] = count;
        }
        k = i-1;
        if(k >= 0 && gameBoard[k][j] == opponent) {
            int flag = 0;
            int count = 0;
            while(k >= 0) {
                if(gameBoard[k][j] == opponent) count++;
                if(gameBoard[k][j] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][j] == 0) break;
                k--;
            }
            if(flag == 1) dir[2] = count;
        }
        k = i+1;
        if(k < 8 && gameBoard[k][j] == opponent) {
            int flag = 0;
            int count = 0;
            while(k < 8) {
                if(gameBoard[k][j] == opponent) count++;
                if(gameBoard[k][j] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][j] == 0) break;
                k++;
            }
            if(flag == 1) dir[3] = count;
        }
        k = i-1;
        l = j+1;
        if(k >= 0 && l < 8 && gameBoard[k][l] == opponent) {
            int flag = 0;
            int count = 0;
            while(k >= 0 && l < 8) {
                if(gameBoard[k][l] == opponent) count++;
                if(gameBoard[k][l] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][l] == 0) break;
                k--;
                l++;
            }
            if(flag == 1) dir[4] = count;
        }
        k = i+1;
        l = j-1;
        if(k < 8 && l >= 0 && gameBoard[k][l] == opponent) {
            int flag = 0;
            int count = 0;
            while(k < 8 && l >= 0) {
                if(gameBoard[k][l] == opponent) count++;
                if(gameBoard[k][l] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][l] == 0) break;
                k++;
                l--;
            }
            if(flag == 1) dir[5] = count;
        }
        k = i+1;
        l = j+1;
        if(k < 8 && l < 8 && gameBoard[k][l] == opponent) {
            int flag = 0;
            int count = 0;
            while(k < 8 && l < 8) {
                if(gameBoard[k][l] == opponent) count++;
                if(gameBoard[k][l] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][l] == 0) break;
                k++;
                l++;
            }
            if(flag == 1) dir[6] = count;
        }
        k = i-1;
        l = j-1;
        if(k >= 0 && l >= 0 && gameBoard[k][l] == opponent) {
            int flag = 0;
            int count = 0;
            while(k >= 0 && l >= 0) {
                if(gameBoard[k][l] == opponent) count++;
                if(gameBoard[k][l] == (-1)*opponent){
                    flag = 1;
                    break;
                }
                if(gameBoard[k][l] == 0) break;
                k--;
                l--;
            }
            if(flag == 1) dir[7] = count;
        }
        return dir;
    }

    public void executeMove(int i, int j, int player){
        //System.out.println("In execute: "+i+" "+j);
        gameBoard[i][j] = player;
        int opponent = player*(-1);
        int k,l;
        int[] dir = checkDirectionForExecute(i,j,opponent);
        //for(boolean b: dir) System.out.print(String.valueOf(b)+" ");
        //System.out.println("");
        if(dir[0] > 0){
            k = j+1;
            while (dir[0] > 0) {
                gameBoard[i][k] = player;
                k++;
                dir[0]--;
            }
        }
        if(dir[1] > 0){
            k = j-1;
            while (dir[1] > 0) {
                gameBoard[i][k] = player;
                k--;
                dir[1]--;
            }
        }
        if(dir[2] > 0){
            k = i-1;
            while (dir[2] > 0) {
                gameBoard[k][j] = player;
                k--;
                dir[2]--;
            }
        }
        if(dir[3] > 0){
            k = i+1;
            while (dir[3] > 0) {
                gameBoard[k][j] = player;
                k++;
                dir[3]--;
            }
        }
        if(dir[4] > 0){
            k = i-1;
            l = j+1;
            while (dir[4] > 0) {
                gameBoard[k][l] = player;
                k--;
                l++;
                dir[4]--;
            }
        }
        if(dir[5] > 0){
            k = i+1;
            l = j-1;
            while (dir[5] > 0) {
                gameBoard[k][l] = player;
                k++;
                l--;
                dir[5]--;
            }
        }
        if(dir[6] > 0){
            k = i+1;
            l = j+1;
            while (dir[6] > 0) {
                gameBoard[k][l] = player;
                k++;
                l++;
                dir[6]--;
            }
        }
        if(dir[7] > 0){
            k = i-1;
            l = j-1;
            while (dir[7] > 0) {
                gameBoard[k][l] = player;
                k--;
                l--;
                dir[7]--;
            }
        }
        countBlackWhite();
        //System.out.println(this);
    }

    public String toString(){
        String str = "  1 2 3 4 5 6 7 8\n";
        for(int i = 0; i < 8; i++){
            str+=String.valueOf(i + 1)+" ";
            for(int j = 0; j < 8; j++){
                if(gameBoard[i][j] == 1)
                    str+="x ";
                else if(gameBoard[i][j] == -1)
                    str+="o ";
                else str+=". ";
            }
            str+="\n";
        }
        str+="\n";
        str+="Player 1: "+String.valueOf(blackCount)+"\n";
        str+="Player 2: "+String.valueOf(whiteCount)+"\n";
        return str;
    }
}
