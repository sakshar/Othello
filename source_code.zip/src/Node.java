import javafx.util.Pair;

import java.util.ArrayList;

/**
 * Created by Asus on 12/8/2017.
 */
public class Node {
    public Board board;
    public double cost;

    public Node(){
        board = new Board();
        cost = 0;
    }

    public Node(Board board){
        this.board = new Board();
        copyBoard(this.board, board);
        this.cost = 0;
    }

    public Node(double cost){
        this.cost = cost;
    }

    public Node(Board board, double cost){
        this.board = new Board();
        copyBoard(this.board, board);
        this.cost = cost;
    }

    public void copyBoard(Board dest, Board src){
        dest.blackCount = src.blackCount;
        dest.whiteCount = src.whiteCount;
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                dest.gameBoard[i][j] = src.gameBoard[i][j];
            }
        }
    }

    public boolean isTerminalNode(Node node){
        node.board.countBlackWhite();
        if(node.board.blackCount + node.board.whiteCount == 64) return true;
        int blackLegalMoves = node.board.validMoves(1).size();
        int whiteLegalMoves = node.board.validMoves(-1).size();
        if(blackLegalMoves + whiteLegalMoves == 0) return true;
        return false;
    }

    public  boolean canContinue(Node node, boolean player){
        if(player && node.board.validMoves(1).size() > 0) return true;
        if(!player && node.board.validMoves(-1).size() > 0) return true;
        return false;
    }

    public double heuristicDiscCount(Node node){
        node.board.countBlackWhite();
        return node.board.blackCount - node.board.whiteCount;
    }

    public double heuristicPositional1(Node node){
        double sum = 0.0;
        int[][] position = {{4, -3, 2, 2, 2, 2, -3, 4},
                {-3, -4, -1 , -1, -1, -1, -4, -3},
                {2, -1, 1, 0, 0, 1, -1, 2},
                {2, -1, 0, 1, 1, 0, -1, 2},
                {2, -1, 0, 1, 1, 0, -1, 2},
                {2, -1, 1, 0, 0, 1, -1, 2},
                {-3, -4, -1 , -1, -1, -1, -4, -3},
                {4, -3, 2, 2, 2, 2, -3, 4}};
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++)
                sum += node.board.gameBoard[i][j]*position[i][j];
        }
        return sum;
    }

    public double heuristicPositional2(Node node){
        double sum = 0.0;
        int[][] position = {{100, -20, 10, 5, 5, 10, -20, 100},
                {-20, -50, -2, -2, -2, -2, -50, -20},
                {10, -2, -1, -1, -1, -1, -2, 10},
                {5, -2, -1, -1, -1, -1, -2, 5},
                {5, -2, -1, -1, -1, -1, -2, 5},
                {10, -2, -1, -1, -1, -1, -2, 10},
                {-20, -50, -2, -2, -2, -2, -50, -20},
                {100, -20, 10, 5, 5, 10, -20, 100}};
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++)
                sum += node.board.gameBoard[i][j]*position[i][j];
        }
        return sum;
    }

    public double heuristicPositional3(Node node){
        double sum = 0.0;
        int[][] position = {{4, 2, 2, 2, 2, 2, 2, 4},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {2, 1, 1, 1, 1, 1, 1, 2},
                {4, 2, 2, 2, 2, 2, 2, 4}};
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++)
                sum += node.board.gameBoard[i][j]*position[i][j];
        }
        return sum;
    }

    public double heuristicMobility(Node node){
        double cPlayer = 0.0, cOpponent = 0.0, mPlayer, mOpponent, w1 = 10.0, w2 = 1.0;

        if(node.board.gameBoard[0][0] == 1) {
            cPlayer++;
        }
        else if(node.board.gameBoard[0][0] == -1){
            cOpponent++;
        }
        if(node.board.gameBoard[0][7] == 1) {
            cPlayer++;
        }
        else if(node.board.gameBoard[0][7] == -1){
            cOpponent++;
        }
        if(node.board.gameBoard[7][0] == 1) {
            cPlayer++;
        }
        else if(node.board.gameBoard[7][0] == -1){
            cOpponent++;
        }
        if(node.board.gameBoard[7][7] == 1) {
            cPlayer++;
        }
        else if(node.board.gameBoard[7][7] == -1){
            cOpponent++;
        }
        mPlayer = node.board.validMoves(1).size();
        mOpponent = node.board.validMoves(-1).size();

        return w1*(cPlayer - cOpponent) + w2*(mPlayer - mOpponent)/(mPlayer + mOpponent);
    }

    public double heuristicMy(Node node){
        ArrayList<Pair<Integer, Integer>> blackLegals = node.board.validMoves(1);
        ArrayList<Pair<Integer, Integer>> whiteLegals = node.board.validMoves(-1);

        int blackSum = 0;
        int whiteSum = 0;
        for (Pair<Integer,Integer> move: blackLegals) {
            int subSum = 0;
            int[] dir = node.board.checkDirectionForExecute(move.getKey(),move.getValue(),-1);
            for (int cost: dir) {
                subSum+=cost;
            }
            blackSum+=subSum;
        }
        for (Pair<Integer,Integer> move: whiteLegals) {
            int subSum = 0;
            int[] dir = node.board.checkDirectionForExecute(move.getKey(),move.getValue(),1);
            for (int cost: dir) {
                subSum+=cost;
            }
            whiteSum+=subSum;
        }
        int mPlayer = blackLegals.size();
        int mOpponent = whiteLegals.size();

        return mPlayer*blackSum - mOpponent*whiteSum;
    }
}
