import javafx.util.Pair;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Asus on 12/12/2017.
 */
public class GameSimulation {
    public int BLACK = 1;
    public int WHITE = -1;
    public double alpha = -99999.99;
    public double beta = 99999.99;
    public int row;
    public int col;
    public int gameOver;
    public int turn;

    //static Font myFont = new Font("Serif", Font.BOLD, 11);
    //static JFrame frame = new JFrame("Othello");

    //JLabel emptyLabel = new JLabel("");
    //emptyLabel.setPreferredSize(new Dimension(175, 100));
    //frame.getContentPane().add(emptyLabel, BorderLayout.CENTER);
    /*static ImageIcon empty = new ImageIcon("empty.png");
    static ImageIcon black = new ImageIcon("black.png");
    static ImageIcon white = new ImageIcon("white.png");
    static ImageIcon legal = new ImageIcon("legal.png");
    static JPanel panel = new JPanel();
    static JLabel[] labels = new JLabel[72];
    static JLabel player1, player2, player1Score, player2Score;*/
    Board board = new Board();

    Scanner scanner = new Scanner(System.in);

    //int row, col;

    ArrayList<Pair<Integer,Integer>> blackLegal, whiteLegal;
    Controller controller = new Controller();

    public GameSimulation(int player){

        if(player == 1) turn = BLACK;
        else turn = WHITE;
        board.initBoard();
        /*frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(new GridLayout(9,8,0,0));
        System.out.println(board);

        int k = 0;
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                switch (board.gameBoard[i][j]) {
                    case 0:
                        labels[k] = new JLabel(empty);
                        break;
                    case 1:
                        labels[k] = new JLabel(black);
                        break;
                    case -1:
                        labels[k] = new JLabel(white);
                }
                panel.add(labels[k]);
                k++;
            }
        }
        player1 = new JLabel("PLAYER 1: ");
        player1.setFont(myFont);
        panel.add(player1);
        player1Score = new JLabel("\t2");
        player1Score.setFont(myFont);
        panel.add(player1Score);
        player2 = new JLabel("PLAYER 2: ");
        player2.setFont(myFont);
        panel.add(player2);
        player2Score = new JLabel("\t2");
        player2Score.setFont(myFont);
        panel.add(player2Score);

        frame.add(panel);
        frame.setSize(500, 450);
        //Display the window.
        frame.pack();
        frame.setVisible(true);*/
    }

    public static void main(String[] args) throws InterruptedException {

        /*int gameCount = 1190;
        for(int heuristic1 = 3; heuristic1 <= 4; heuristic1++){
            for(int heuristic2 = 1; heuristic2 <= 4; heuristic2++){
                for(int depth1 = 1; depth1 <= 7; depth1++){
                    for(int depth2 = 1; depth2 <= 7; depth2++){
                        for(int player = 1; player <= 2; player++){
                            GameSimulation gameSimulation = new GameSimulation(player);
                            while (true) {
                                gameSimulation.blackLegal = gameSimulation.board.validMoves(gameSimulation.BLACK);
                                gameSimulation.whiteLegal = gameSimulation.board.validMoves(gameSimulation.WHITE);
                                gameSimulation.gameOver = gameSimulation.blackLegal.size() + gameSimulation.whiteLegal.size();
                                if (gameSimulation.gameOver == 0) break;
                                if(gameSimulation.turn == gameSimulation.BLACK){
                                    //System.out.println("To Move: Player 1");
                                    if(gameSimulation.blackLegal.size() > 0){
                                        // WHEN PLAYED BY BOT
                                        MoveValue moveValue = gameSimulation.controller.minMaxWithPruning(new Node(gameSimulation.board), depth1, gameSimulation.alpha, gameSimulation.beta, true, heuristic1);
                                        //gameSimulation.board.printLegalMoves(gameSimulation.blackLegal);
                                        //System.out.println("Move: "+String.valueOf(moveValue.returnMove.getKey() + 1)+" "+String.valueOf(moveValue.returnMove.getValue() + 1));
                                        gameSimulation.board.executeMove(moveValue.returnMove.getKey(), moveValue.returnMove.getValue(), gameSimulation.BLACK);
                                    }
                                    else {
                                        //System.out.println("No legal moves for Player 1");
                                    }
                                    gameSimulation.turn = gameSimulation.WHITE;
                                }
                                else if (gameSimulation.turn == gameSimulation.WHITE) {
                                    //System.out.println("To Move: Player 2");
                                    if (gameSimulation.whiteLegal.size() > 0) {
                                        // WHEN PLAYED BY BOT
                                        MoveValue moveValue = gameSimulation.controller.minMaxWithPruning(new Node(gameSimulation.board), depth2, gameSimulation.alpha, gameSimulation.beta, false, heuristic2);
                                        //gameSimulation.board.printLegalMoves(gameSimulation.whiteLegal);
                                        //System.out.println("Move: " + String.valueOf(moveValue.returnMove.getKey() + 1) + " " + String.valueOf(moveValue.returnMove.getValue() + 1));
                                        gameSimulation.board.executeMove(moveValue.returnMove.getKey(), moveValue.returnMove.getValue(), gameSimulation.WHITE);
                                        //System.out.println(gameSimulation.board);
                                    }
                                    else {
                                        //System.out.println("No legal moves for Player 2");
                                    }
                                    gameSimulation.turn = gameSimulation.BLACK;
                                }

                            }
                            gameSimulation.board.countBlackWhite();
                            System.out.println(gameSimulation.board);
                            System.out.println("Player 1: "+gameSimulation.board.blackCount);
                            System.out.println("Player 2: "+gameSimulation.board.whiteCount);
                            /*JLabel winnerTag = new JLabel();
                            JLabel winner = new JLabel();
                            winner.setFont(gameSimulation.myFont);
                            winnerTag.setFont(gameSimulation.myFont);
                            gameSimulation.panel.add(winnerTag);
                            gameSimulation.panel.add(winner);*/
            /*                int result;
                            if (gameSimulation.board.blackCount > gameSimulation.board.whiteCount) {
                                System.out.println("Player 1 Won");
                                //winnerTag.setText("WINNER: ");
                                //winner.setText("PLAYER 1");
                                result = 1;
                            }
                            else if (gameSimulation.board.blackCount < gameSimulation.board.whiteCount) {
                                System.out.println("Player 2 Won");
                                //winnerTag.setText("WINNER: ");
                                //winner.setText("PLAYER 2");
                                result = 2;
                            }
                            else {
                                System.out.println("GAME has DRAWN");
                                //winnerTag.setText("MATCH ");
                                //winner.setText("DRAWN");
                                result = 0;
                            }

                            PrintWriter pw = null;

                            try {
                                File file = new File("simulation_log.txt");
                                FileWriter fw = new FileWriter(file, true);
                                pw = new PrintWriter(fw);
                                pw.println(gameCount+". GameStarter: "+player);
                                pw.println("Player 1: heuristic - "+heuristic1+" depth - "+depth1+" score - "+gameSimulation.board.blackCount);
                                pw.println("Player 2: heuristic - "+heuristic2+" depth - "+depth2+" score - "+gameSimulation.board.whiteCount);
                                pw.println("Winner: "+result);
                                pw.println("---------------------------------------------------------------------------------");
                                pw.println("---------------------------------------------------------------------------------");
                            } catch (IOException e) {
                                e.printStackTrace();
                            } finally {
                                if (pw != null) {
                                    pw.close();
                                }
                            }
                            gameCount++;
                            Thread.sleep(1000);
                        }
                    }
                }
            }
        }*/
        int player=1, heuristic1=5, heuristic2=3, depth1=4, depth2=4;
        GameSimulation gameSimulation = new GameSimulation(player);
        while (true) {
            gameSimulation.blackLegal = gameSimulation.board.validMoves(gameSimulation.BLACK);
            gameSimulation.whiteLegal = gameSimulation.board.validMoves(gameSimulation.WHITE);
            gameSimulation.gameOver = gameSimulation.blackLegal.size() + gameSimulation.whiteLegal.size();
            if (gameSimulation.gameOver == 0) break;
            if(gameSimulation.turn == gameSimulation.BLACK){
                System.out.println("To Move: Player 1");
                if(gameSimulation.blackLegal.size() > 0){
                    // WHEN PLAYED BY BOT
                    MoveValue moveValue = gameSimulation.controller.minMaxWithPruning(new Node(gameSimulation.board),depth1, gameSimulation.alpha, gameSimulation.beta, true, heuristic1);
                    gameSimulation.board.printLegalMoves(gameSimulation.blackLegal);
                    System.out.println("Move: "+String.valueOf(moveValue.returnMove.getKey() + 1)+" "+String.valueOf(moveValue.returnMove.getValue() + 1));
                    gameSimulation.board.executeMove(moveValue.returnMove.getKey(), moveValue.returnMove.getValue(), gameSimulation.BLACK);
                }
                else {
                    System.out.println("No legal moves for Player 1");
                }
                gameSimulation.turn = gameSimulation.WHITE;
            }
            else if (gameSimulation.turn == gameSimulation.WHITE) {
                System.out.println("To Move: Player 2");
                if (gameSimulation.whiteLegal.size() > 0) {
                    // WHEN PLAYED BY BOT
                    MoveValue moveValue = gameSimulation.controller.minMaxWithPruning(new Node(gameSimulation.board), depth2, gameSimulation.alpha, gameSimulation.beta, false, heuristic2);
                    gameSimulation.board.printLegalMoves(gameSimulation.whiteLegal);
                    System.out.println("Move: " + String.valueOf(moveValue.returnMove.getKey() + 1) + " " + String.valueOf(moveValue.returnMove.getValue() + 1));
                    gameSimulation.board.executeMove(moveValue.returnMove.getKey(), moveValue.returnMove.getValue(), gameSimulation.WHITE);
                    //System.out.println(gameSimulation.board);
                }
                else {
                    System.out.println("No legal moves for Player 2");
                }
                gameSimulation.turn = gameSimulation.BLACK;
            }
            System.out.println(gameSimulation.board);
            //System.out.println("Player 1: "+gameSimulation.board.blackCount);
            //System.out.println("Player 2: "+gameSimulation.board.whiteCount);
        }
        gameSimulation.board.countBlackWhite();

        int result;
        if (gameSimulation.board.blackCount > gameSimulation.board.whiteCount) {
            System.out.println("Player 1 Won");
            //winnerTag.setText("WINNER: ");
            //winner.setText("PLAYER 1");
            result = 1;
        }
        else if (gameSimulation.board.blackCount < gameSimulation.board.whiteCount) {
            System.out.println("Player 2 Won");
            //winnerTag.setText("WINNER: ");
            //winner.setText("PLAYER 2");
            result = 2;
        }
        else {
            System.out.println("GAME has DRAWN");
            //winnerTag.setText("MATCH ");
            //winner.setText("DRAWN");
            result = 0;
        }

        /*PrintWriter pw = null;
        try {
            File file = new File("simulation_log.txt");
            FileWriter fw = new FileWriter(file, true);
            pw = new PrintWriter(fw);
            pw.println("GameStarter: "+player);
            pw.println("Player 1: heuristic - "+heuristic1+" depth - "+depth1+" score - "+gameSimulation.board.blackCount);
            pw.println("Player 2: heuristic - "+heuristic2+" depth - "+depth2+" score - "+gameSimulation.board.whiteCount);
            pw.println("Winner: "+result);
            pw.println("---------------------------------------------------------------------------------");
            pw.println("---------------------------------------------------------------------------------");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (pw != null) {
                pw.close();
            }
        }*/
    }
}
