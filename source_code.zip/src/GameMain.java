import javafx.util.Pair;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Asus on 12/7/2017.
 */
public class GameMain {
    static int BLACK = 1;
    static int WHITE = -1;
    static double alpha = -99999.99;
    static double beta = 99999.99;
    static int row;
    static int col;
    static int gameOver;
    static int turn = BLACK;

    static Font myFont = new Font("Serif", Font.BOLD, 11);
    static JFrame frame = new JFrame("Othello");

    static ImageIcon empty = new ImageIcon("empty.png");
    static ImageIcon black = new ImageIcon("black.png");
    static ImageIcon white = new ImageIcon("white.png");
    static ImageIcon legal = new ImageIcon("legal.png");
    static JPanel panel = new JPanel();
    static JLabel[] labels = new JLabel[72];
    static JLabel player1, player2, player1Score, player2Score;
    static Board board = new Board();

    //Scanner scanner = new Scanner(System.in);

    //int row, col;

    static ArrayList<Pair<Integer,Integer>> blackLegal, whiteLegal;
    static Controller controller = new Controller();

    public GameMain(){

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(new GridLayout(9,8,0,0));
        board.initBoard();
        System.out.println(board);

        int k = 0;
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                switch (board.gameBoard[i][j]) {
                    case 0:
                        labels[k] = new JLabel(empty);
                        break;
                    case 1:
                        labels[k] = new JLabel(black);
                        break;
                    case -1:
                        labels[k] = new JLabel(white);
                }
                panel.add(labels[k]);
                k++;
            }
        }
        player1 = new JLabel("PLAYER 1: ");
        player1.setFont(myFont);
        panel.add(player1);
        player1Score = new JLabel("\t2");
        player1Score.setFont(myFont);
        panel.add(player1Score);
        player2 = new JLabel("PLAYER 2: ");
        player2.setFont(myFont);
        panel.add(player2);
        player2Score = new JLabel("\t2");
        player2Score.setFont(myFont);
        panel.add(player2Score);

        frame.add(panel);
        frame.setSize(500, 450);
        //Display the window.
        frame.pack();
        frame.setVisible(true);

        panel.addMouseListener(new MouseAdapter() {// provides empty implementation of all
            // MouseListener`s methods, allowing us to
            // override only those which interests us
            @Override //I override only one method for presentation
            public void mousePressed(MouseEvent e) {
                if(turn == BLACK){
                    System.out.print("Move: ");
                    System.out.println(e.getX()/75+" "+e.getY()/75);
                    col = e.getX()/(75);
                    row = e.getY()/(75);
                    //System.out.println(String.valueOf(row)+" "+String.valueOf(col));
                    //execute the move and change the board accordingly
                    board.executeMove(row,col,BLACK);
                    System.out.println(board);
                    turn = WHITE;
                }
            }
        });
    }

    public static void main(String[] args) throws InterruptedException {
        int depth = 3;
        int heuristic = 6;
        GameMain gameMain = new GameMain();

        while (true) {
            gameMain.blackLegal = board.validMoves(BLACK);
            gameMain.whiteLegal = board.validMoves(WHITE);
            gameMain.gameOver = blackLegal.size() + whiteLegal.size();
            if (gameMain.gameOver == 0) break;
            if (gameMain.turn == BLACK) {
                gameMain.blackLegal = gameMain.board.validMoves(BLACK);
                //System.out.println("To Move: Player 1");
                if (gameMain.blackLegal.size() > 0) {
                    // WHEN PLAYED BY HUMAN
                    //gameMain.board.printLegalMoves(gameMain.blackLegal);
                    for (Pair<Integer, Integer> legalMove : gameMain.blackLegal) {
                        gameMain.labels[legalMove.getKey() * 8 + legalMove.getValue()].setIcon(gameMain.legal);
                    }
                    Thread.sleep(1000);
                }
                else {
                    //System.out.println("No legal moves for Player 1");
                    gameMain.turn = WHITE;
                }
            }
            else if (gameMain.turn == WHITE) {
                //System.out.println("To Move: Player 2");
                if (gameMain.whiteLegal.size() > 0) {
                        // WHEN PLAYED BY BOT
                    MoveValue moveValue = gameMain.controller.minMaxWithPruning(new Node(gameMain.board),depth, alpha, beta, false,heuristic);
                    //gameMain.board.printLegalMoves(gameMain.whiteLegal);
                    System.out.println("Move: " + String.valueOf(moveValue.returnMove.getKey() + 1) + " " + String.valueOf(moveValue.returnMove.getValue() + 1));
                    gameMain.board.executeMove(moveValue.returnMove.getKey(), moveValue.returnMove.getValue(), WHITE);
                    System.out.println(gameMain.board);
                        //board = node.board;
                }
                else {
                    //System.out.println("No legal moves for Player 2");
                }
                gameMain.turn = BLACK;
            }
            //System.out.println(gameMain.board);
            int k = 0;
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    switch (gameMain.board.gameBoard[i][j]) {
                        case 0:
                            gameMain.labels[k].setIcon(gameMain.empty);
                            break;
                        case 1:
                            gameMain.labels[k].setIcon(gameMain.black);
                            break;
                        case -1:
                            gameMain.labels[k].setIcon(gameMain.white);
                    }
                    k++;
                }
            }
            gameMain.player1Score.setText(String.valueOf(gameMain.board.blackCount));
            gameMain.player2Score.setText(String.valueOf(gameMain.board.whiteCount));
            //Thread.sleep(1000);
        }

        gameMain.board.countBlackWhite();
        JLabel winnerTag = new JLabel();
        JLabel winner = new JLabel();
        winner.setFont(gameMain.myFont);
        winnerTag.setFont(gameMain.myFont);
        gameMain.panel.add(winnerTag);
        gameMain.panel.add(winner);
        if (gameMain.board.blackCount > gameMain.board.whiteCount) {
            System.out.println("Player 1 Won");
            winnerTag.setText("WINNER: ");
            winner.setText("PLAYER 1");
        }
        else if (gameMain.board.blackCount < gameMain.board.whiteCount) {
            System.out.println("Player 2 Won");
            winnerTag.setText("WINNER: ");
            winner.setText("PLAYER 2");

        }
        else {
            System.out.println("GAME has DRAWN");
            winnerTag.setText("MATCH ");
            winner.setText("DRAWN");
        }
    }
}

