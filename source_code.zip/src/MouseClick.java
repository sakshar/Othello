import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Created by Asus on 12/10/2017.
 */
public class MouseClick extends JFrame {
    private int row;
    private int col;
}
